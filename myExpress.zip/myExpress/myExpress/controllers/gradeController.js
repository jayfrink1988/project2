
const express = require('express');
const router = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: "Courses"})
});
var studentGrades = [
    {
        name: "Node.js Programming",
        csc141grade: "A+",
		csc142grade: "A+",
		csc240grade: "A+",
		csc241grade: "A+"
    },
    {
        name: "Node.js Programming",
        csc141grade: "A+",
		csc142grade: "A+",
		csc240grade: "A+",
		csc241grade: "A+"
    }
];
console.log('in homeController pass 1');
router.showCourses = (req, res) => {
    res.render("courses", {
        allCourses: studentGrades, title: "Course List"
    });
};
console.log('in homeController pass 2');
router.addCourses = (req, res) => {
    console.log("in homeController addCourses");
    var studentName = req.body.name;
    console.log("name " + studentName);
    //var csc141 = parseInt(req.body.csc141grade);
	var csc141 = req.body.csc141grade;
    var c141 = csc141.trim().toUpperCase();
	var csc142 = req.body.csc142grade;
	var c142 = csc142.trim().toUpperCase();
	var csc240 = req.body.csc240grade;
	var c240 = csc240.trim().toUpperCase();
	var csc241 = req.body.csc241grade;
	var c241 = csc241.trim().toUpperCase();
	console.log(c241);
    let allCourses = studentGrades;

//mongodb scipt	
  MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("test");
  //var myobj = { name: studentName,partialgpa:partialgpa};
  var myobj = { name: studentName};
  
  dbo.collection("contacts").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 document inserted");
    db.close();
  });
});
//mongo db script 

    allCourses.push({name: studentName, csc141grade: c141,csc142grade: c142,csc240grade: c240,csc241grade: c241});
    res.render("courses", {
        allCourses: studentGrades
    });
};

console.log('in homeController pass 3');
router.getNewCourse = (req, res) => {
    console.log("in homeController getNewCourse");
    res.render("newcourse", {title: "New Course"});
};
module.exports = router;

